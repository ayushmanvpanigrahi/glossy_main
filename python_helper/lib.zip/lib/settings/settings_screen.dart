import 'package:flutter/material.dart';
import '../app_colors.dart';
import '../ai_status.dart';
import 'settings_models.dart';
import 'settings_service.dart';
import 'settings_rows.dart';

// Section widgets
import 'account_section/account_section.dart';
import 'ai_configuration_section/ai_config_section.dart';
import 'reader_section/reader_section.dart';
import 'general_section/general_section.dart';

// Detail screens
import 'account_section/profile_screen/profile_screen.dart';
import 'account_section/plan_screen/plan_screen.dart';
import 'ai_configuration_section/api_keys_screen/api_keys_screen.dart';
import 'ai_configuration_section/preferred_model_screen/preferred_model_screen.dart';
import 'ai_configuration_section/ai_provider_screen/ai_provider_screen.dart';
import 'ai_configuration_section/custom_prompt_template_screen/custom_prompt_template_screen.dart';
import 'ai_configuration_section/rag_book_qna_screen/rag_book_qna_screen.dart';
import 'ai_configuration_section/service_health_screen/service_health_screen.dart';
import 'reader_section/apperences_screen/apperences_screen.dart';
import 'general_section/notification_screen/notification_screen.dart';
import 'general_section/language_screen/language_screen.dart';
import 'general_section/privacy_and_data_screen/privacy_and_data_screen.dart';
import 'general_section/help_and_about_screen/help_and_about_screen.dart';

// ---------------------------------------------------------------------------
// SettingsScreen — warm iOS-style grouped settings.
// All state lives here and is passed down to sections and detail screens.
// ---------------------------------------------------------------------------

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static bool _hasAutoValidatedThisSession = false;

  final _service = SettingsService();

  // ── Controllers ───────────────────────────────────────────────────────────
  final _orKeyCtrl = TextEditingController();
  final _groqKeyCtrl = TextEditingController();
  final _geminiKeyCtrl = TextEditingController();
  final _modelSearchCtrl = TextEditingController();

  // ── Obscure toggles ───────────────────────────────────────────────────────
  bool _obscureOr = true;
  bool _obscureGroq = true;
  bool _obscureGemini = true;

  // ── Loading ───────────────────────────────────────────────────────────────
  bool _isLoading = true;
  bool _isSaving = false;
  bool _isModelsLoading = true;
  String? _modelsFetchError;
  List<String> _modelFetchWarnings = [];

  // ── Key status ────────────────────────────────────────────────────────────
  KeyStatus _orStatus = KeyStatus.idle;
  KeyStatus _groqStatus = KeyStatus.idle;
  KeyStatus _geminiStatus = KeyStatus.idle;

  // ── Model ping ────────────────────────────────────────────────────────────
  ModelPingResult? _modelPingResult;
  bool _isPinging = false;

  // ── Model state ───────────────────────────────────────────────────────────
  List<OpenRouterModel> _allModels = [];
  String? _selectedModelId;
  ModelProvider _selectedModelProvider = ModelProvider.openRouter;
  bool _freeOnly = false;
  String _searchQuery = '';
  Set<ModelProvider> _selectedProviders = Set.from(ModelProvider.values);
  Set<ModelType> _selectedTypes = Set.from(ModelType.values);

  // ── RAG ───────────────────────────────────────────────────────────────────
  String _embeddingMode = 'api';
  String _indexingTrigger = 'onAdd';

  // ── Reader ────────────────────────────────────────────────────────────────
  bool _darkMode = false;
  bool _autoScroll = true;
  final String _fontSize = 'Medium';
  final String _pageLayout = 'Single page';

  // ── General ───────────────────────────────────────────────────────────────
  final bool _notificationsEnabled = true;
  final String _language = 'English';

  // ── Account (replace with real auth) ─────────────────────────────────────
  String get _userName => 'Aarav Mehta';
  String get _userEmail => 'aarav@glossy.app';
  bool get _isPro => false;
  String get _appVersion => 'v0.4.2';

  String get _aiStatus => aiStatusNotifier.value;

  // ── Lifecycle ─────────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _orKeyCtrl.dispose();
    _groqKeyCtrl.dispose();
    _geminiKeyCtrl.dispose();
    _modelSearchCtrl.dispose();
    super.dispose();
  }

  // ── Init ──────────────────────────────────────────────────────────────────

  Future<void> _init() async {
    await Future.wait([_loadSaved(), _loadRag()]);
    await _fetchModels();
    if (!_hasAutoValidatedThisSession) {
      await _autoValidateAll();
      _hasAutoValidatedThisSession = true;
    }
  }

  Future<void> _loadSaved() async {
    final s = await _service.loadSavedSettings();
    setState(() {
      if (s.apiKey != null) _orKeyCtrl.text = s.apiKey!;
      if (s.groqApiKey != null) _groqKeyCtrl.text = s.groqApiKey!;
      _selectedModelId = s.modelId;
      _selectedModelProvider = s.modelProvider;
      _isLoading = false;
    });
  }

  Future<void> _loadRag() async {
    final r = await _service.loadRagSettings();
    setState(() {
      _embeddingMode = r.embeddingMode ?? 'api';
      _indexingTrigger = r.indexingTrigger ?? 'onAdd';
      if (r.embeddingApiKey != null) _geminiKeyCtrl.text = r.embeddingApiKey!;
    });
  }

  // ── Model fetching ────────────────────────────────────────────────────────

  Future<void> _fetchModels() async {
    setState(() {
      _isModelsLoading = true;
      _modelsFetchError = null;
      _modelFetchWarnings = [];
    });
    try {
      final result = await _service.fetchAllModels(
        groqApiKey: _groqKeyCtrl.text.trim(),
        geminiApiKey: _geminiKeyCtrl.text.trim(),
      );
      setState(() {
        _allModels = result.models;
        _modelFetchWarnings = result.errors;
        _isModelsLoading = false;
      });
      await _ensureValidModelSelected();
    } catch (_) {
      setState(() {
        _modelsFetchError = 'Could not connect. Check your internet.';
        _isModelsLoading = false;
      });
    }
  }

  Future<void> _ensureValidModelSelected() async {
    if (_allModels.isEmpty) {
      if (_selectedModelId != null) {
        setState(() => _selectedModelId = null);
        await _service.deleteModelId();
      }
      return;
    }
    final stillValid = _allModels.any((m) => m.id == _selectedModelId);
    if (_selectedModelId == null || !stillValid) {
      final fallback = _allModels.first;
      setState(() => _selectedModelId = fallback.id);
      await _service.saveModelId(fallback.id);
    }
  }

  List<OpenRouterModel> get _filteredModels {
    final q = _searchQuery.toLowerCase();
    return _allModels.where((m) {
      if (_freeOnly && !m.isFree) return false;
      if (!_selectedProviders.contains(m.effectiveProvider)) return false;
      if (!_selectedTypes.contains(m.type)) return false;
      if (q.isNotEmpty &&
          !m.name.toLowerCase().contains(q) &&
          !m.id.toLowerCase().contains(q)) {
        return false;
      }
      return true;
    }).toList();
  }

  // ── Validation ────────────────────────────────────────────────────────────

  Future<void> _autoValidateAll() async {
    final or = _orKeyCtrl.text.trim();
    final groq = _groqKeyCtrl.text.trim();
    final gemini = _geminiKeyCtrl.text.trim();
    await Future.wait([
      if (or.isNotEmpty) _validateOrKey(or, announce: false),
      if (groq.isNotEmpty) _validateGroqKey(groq, announce: false),
      if (gemini.isNotEmpty) _validateGeminiKey(gemini, announce: false),
    ]);
    _syncAiStatus();
  }

  Future<void> _validateOrKey(String key, {bool announce = true}) async {
    setState(() => _orStatus = KeyStatus.checking);
    final result = await _service.validateOpenRouterKey(key);
    setState(() => _orStatus = _toKeyStatus(result));
    if (announce) {
      _syncAiStatus();
      _showSnack(_orLabel(result));
    }
  }

  Future<void> _validateGroqKey(String key, {bool announce = true}) async {
    setState(() => _groqStatus = KeyStatus.checking);
    final result = await _service.validateGroqKey(key);
    setState(() => _groqStatus = _toKeyStatus(result));
    if (announce) {
      _syncAiStatus();
      _showSnack(_groqLabel(result));
    }
  }

  Future<void> _validateGeminiKey(String key, {bool announce = true}) async {
    setState(() => _geminiStatus = KeyStatus.checking);
    final result = await _service.validateGeminiKey(key);
    setState(() => _geminiStatus = _toKeyStatus(result));
    if (announce) _showSnack(_geminiLabel(result));
  }

  KeyStatus _toKeyStatus(ValidationResult r) => switch (r) {
    ValidationResult.valid => KeyStatus.valid,
    ValidationResult.invalid => KeyStatus.invalid,
    ValidationResult.networkError => KeyStatus.networkError,
    ValidationResult.unknown => KeyStatus.valid,
  };

  void _syncAiStatus() {
    final anyActive =
        _orStatus == KeyStatus.valid || _groqStatus == KeyStatus.valid;
    final anyChecking =
        _orStatus == KeyStatus.checking || _groqStatus == KeyStatus.checking;
    aiStatusNotifier.value = anyChecking
        ? 'checking'
        : anyActive
        ? 'active'
        : 'inactive';
    setState(() {});
  }

  // ── Model ping ────────────────────────────────────────────────────────────

  Future<void> _pingModel() async {
    final modelId = _selectedModelId;
    if (modelId == null) return;
    final apiKey = switch (_selectedModelProvider) {
      ModelProvider.groq => _groqKeyCtrl.text.trim(),
      ModelProvider.gemini => _geminiKeyCtrl.text.trim(),
      ModelProvider.openRouter => _orKeyCtrl.text.trim(),
    };
    setState(() {
      _isPinging = true;
      _modelPingResult = null;
    });
    final result = await _service.pingModel(
      modelId: modelId,
      provider: _selectedModelProvider,
      apiKey: apiKey,
    );
    setState(() {
      _isPinging = false;
      _modelPingResult = result;
    });
  }

  // ── Save ──────────────────────────────────────────────────────────────────

  Future<void> _save() async {
    setState(() => _isSaving = true);
    await _service.saveAllSettings(
      openRouterKey: _orKeyCtrl.text.trim(),
      groqKey: _groqKeyCtrl.text.trim(),
      geminiKey: _geminiKeyCtrl.text.trim(),
      modelId: _selectedModelId,
      modelProvider: _selectedModelProvider,
      embeddingMode: _embeddingMode,
      indexingTrigger: _indexingTrigger,
    );
    await _autoValidateAll();
    setState(() => _isSaving = false);
    _showSnack('Settings saved');
  }

  // ── Navigation ────────────────────────────────────────────────────────────

  void _push(Widget screen) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));

  void _openProfile() => _push(const ProfileScreen());
  void _openPlan() => _push(const PlanScreen());

  void _openApiKeys() => _push(
    ApiKeysScreen(
      orKeyCtrl: _orKeyCtrl,
      obscureOr: _obscureOr,
      onToggleObscureOr: () => setState(() => _obscureOr = !_obscureOr),
      orStatus: _orStatus,
      onValidateOr: () {
        final k = _orKeyCtrl.text.trim();
        if (k.isNotEmpty) _validateOrKey(k);
      },
      groqKeyCtrl: _groqKeyCtrl,
      obscureGroq: _obscureGroq,
      onToggleObscureGroq: () => setState(() => _obscureGroq = !_obscureGroq),
      groqStatus: _groqStatus,
      onValidateGroq: () {
        final k = _groqKeyCtrl.text.trim();
        if (k.isNotEmpty) _validateGroqKey(k);
      },
      geminiKeyCtrl: _geminiKeyCtrl,
      obscureGemini: _obscureGemini,
      onToggleObscureGemini: () =>
          setState(() => _obscureGemini = !_obscureGemini),
      geminiStatus: _geminiStatus,
      onValidateGemini: () {
        final k = _geminiKeyCtrl.text.trim();
        if (k.isNotEmpty) _validateGeminiKey(k);
      },
      onSave: _save,
      isSaving: _isSaving,
    ),
  );

  void _openModelPicker() => _push(
    PreferredModelScreen(
      isModelsLoading: _isModelsLoading,
      modelsFetchError: _modelsFetchError,
      onRefresh: _refreshModels,
      searchController: _modelSearchCtrl,
      onSearchChanged: (v) => setState(() => _searchQuery = v),
      freeOnly: _freeOnly,
      onFreeOnlyChanged: (v) => setState(() => _freeOnly = v),
      selectedProviders: _selectedProviders,
      onProvidersChanged: (v) => setState(() => _selectedProviders = v),
      selectedTypes: _selectedTypes,
      onTypesChanged: (v) => setState(() => _selectedTypes = v),
      allModels: _allModels,
      filteredModels: _filteredModels,
      fetchWarnings: _modelFetchWarnings,
      selectedModelId: _selectedModelId,
      onSelectModel: _handleModelSelect,
      isPinging: _isPinging,
      pingResult: _modelPingResult,
      onPing: _pingModel,
    ),
  );

  void _openAiProvider() => _push(const AiProviderScreen());
  void _openCustomPrompt() => _push(const CustomPromptTemplateScreen());

  void _openRag() => _push(
    RagBookQnaScreen(
      embeddingMode: _embeddingMode,
      onEmbeddingModeChanged: (v) => setState(() => _embeddingMode = v),
      embeddingApiKeyController: _geminiKeyCtrl,
      obscureEmbeddingKey: _obscureGemini,
      onToggleObscureEmbeddingKey: () =>
          setState(() => _obscureGemini = !_obscureGemini),
      indexingTrigger: _indexingTrigger,
      onIndexingTriggerChanged: (v) => setState(() => _indexingTrigger = v),
      onSave: _save,
      isSaving: _isSaving,
    ),
  );

  void _openHealth() => _push(
    ServiceHealthScreen(
      orStatus: _orStatus,
      groqStatus: _groqStatus,
      geminiStatus: _geminiStatus,
      aiStatus: _aiStatus,
      pingResult: _modelPingResult,
      selectedModelId: _selectedModelId,
    ),
  );

  void _openAppearances() => _push(const ApperencesScreen());
  void _openNotifications() => _push(const NotificationScreen());
  void _openLanguage() => _push(const LanguageScreen());
  void _openPrivacy() => _push(const PrivacyAndDataScreen());
  void _openHelp() => _push(HelpAndAboutScreen(appVersion: _appVersion));

  Future<void> _handleModelSelect(String id) async {
    final model = _allModels.firstWhere((m) => m.id == id);
    setState(() {
      _selectedModelId = id;
      _selectedModelProvider = model.provider;
      _modelPingResult = null;
    });
    await _service.saveModelId(id);
    await _service.saveModelProvider(model.provider);
  }

  Future<void> _refreshModels() async {
    await _fetchModels();
    await _autoValidateAll();
  }

  // ── Snack labels ──────────────────────────────────────────────────────────

  String _orLabel(ValidationResult r) => switch (r) {
    ValidationResult.valid => 'OpenRouter key is valid ✓',
    ValidationResult.invalid => 'OpenRouter key is invalid',
    ValidationResult.networkError => 'Could not reach OpenRouter',
    ValidationResult.unknown => 'OpenRouter key accepted',
  };
  String _groqLabel(ValidationResult r) => switch (r) {
    ValidationResult.valid => 'Groq key is valid ✓',
    ValidationResult.invalid => 'Groq key is invalid',
    ValidationResult.networkError => 'Could not reach Groq',
    ValidationResult.unknown => 'Groq key accepted',
  };
  String _geminiLabel(ValidationResult r) => switch (r) {
    ValidationResult.valid => 'Gemini key is valid ✓',
    ValidationResult.invalid => 'Gemini key is invalid',
    ValidationResult.networkError => 'Could not reach Google',
    ValidationResult.unknown => 'Gemini key accepted',
  };

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            fontFamily: 'Inter',
            color: AppColors.ink,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: AppColors.paper,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: AppColors.border),
        ),
        margin: const EdgeInsets.only(left: 16, right: 16, bottom: 24),
        elevation: 4,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: AppColors.secondary,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.secondary,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // ── Header
            SliverToBoxAdapter(
              child: _SettingsHeader(isSaving: _isSaving, onSave: _save),
            ),

            // ── Account
            SliverToBoxAdapter(
              child: AccountSection(
                userName: _userName,
                userEmail: _userEmail,
                isPro: _isPro,
                onAccountTap: _openProfile,
                onProTap: _openPlan,
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 28)),

            // ── AI Configuration
            SliverToBoxAdapter(
              child: AiConfigSection(
                selectedModelId: _selectedModelId,
                orStatus: _orStatus,
                groqStatus: _groqStatus,
                onProviderTap: _openAiProvider,
                onModelTap: _openModelPicker,
                onApiKeysTap: _openApiKeys,
                onPromptTap: _openCustomPrompt,
                onRagTap: _openRag,
                onHealthTap: _openHealth,
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 28)),

            // ── Reader
            SliverToBoxAdapter(
              child: ReaderSection(
                fontSize: _fontSize,
                darkMode: _darkMode,
                onDarkModeChanged: (v) => setState(() => _darkMode = v),
                autoScroll: _autoScroll,
                onAutoScrollChanged: (v) => setState(() => _autoScroll = v),
                pageLayout: _pageLayout,
                onAppearancesTap: _openAppearances,
                onPageLayoutTap: _openAppearances,
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 28)),

            // ── General
            SliverToBoxAdapter(
              child: GeneralSection(
                notificationsEnabled: _notificationsEnabled,
                language: _language,
                appVersion: _appVersion,
                onNotificationsTap: _openNotifications,
                onLanguageTap: _openLanguage,
                onPrivacyTap: _openPrivacy,
                onHelpTap: _openHelp,
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 28)),

            // ── Sign out
            SliverToBoxAdapter(child: SignOutButton(onTap: _showSignOutDialog)),

            const SliverToBoxAdapter(child: SizedBox(height: 40)),
          ],
        ),
      ),
    );
  }

  void _showSignOutDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.paper,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Sign out?',
          style: TextStyle(fontFamily: 'PlayfairDisplay', fontSize: 20),
        ),
        content: const Text(
          'Your settings will remain saved on this device.',
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 14,
            color: AppColors.muted,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'Cancel',
              style: TextStyle(fontFamily: 'Inter', color: AppColors.muted),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _showSnack('Signed out');
            },
            child: const Text(
              'Sign out',
              style: TextStyle(
                fontFamily: 'Inter',
                color: AppColors.danger,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------

class _SettingsHeader extends StatelessWidget {
  const _SettingsHeader({required this.isSaving, required this.onSave});
  final bool isSaving;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 20, 22, 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'PREFERENCES',
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.2,
                  color: AppColors.muted,
                ),
              ),
              SizedBox(height: 4),
              Text(
                'Settings',
                style: TextStyle(
                  fontFamily: 'PlayfairDisplay',
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  fontStyle: FontStyle.italic,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
          const Spacer(),
          GestureDetector(
            onTap: isSaving ? null : onSave,
            child: isSaving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.primary,
                    ),
                  )
                : const Text(
                    'Save',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: AppColors.primary,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
