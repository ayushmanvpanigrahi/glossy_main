import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_rows.dart';
import '../../common_widgets.dart';

class RagBookQnaScreen extends StatelessWidget {
  const RagBookQnaScreen({
    super.key,
    required this.embeddingMode,
    required this.onEmbeddingModeChanged,
    required this.embeddingApiKeyController,
    required this.obscureEmbeddingKey,
    required this.onToggleObscureEmbeddingKey,
    required this.indexingTrigger,
    required this.onIndexingTriggerChanged,
    required this.onSave,
    required this.isSaving,
  });

  final String embeddingMode;
  final ValueChanged<String> onEmbeddingModeChanged;
  final TextEditingController embeddingApiKeyController;
  final bool obscureEmbeddingKey;
  final VoidCallback onToggleObscureEmbeddingKey;
  final String indexingTrigger;
  final ValueChanged<String> onIndexingTriggerChanged;
  final VoidCallback onSave;
  final bool isSaving;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'RAG / book Q&A',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
        actions: [
          TextButton(
            onPressed: isSaving ? null : onSave,
            child: const Text(
              'Save',
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.primary,
              ),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SettingsSectionLabel('Embedding mode'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.stage,
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedToggle<String>(
                    options: const [('api', 'API'), ('local', 'On-device')],
                    selected: embeddingMode,
                    onChanged: onEmbeddingModeChanged,
                  ),
                  if (embeddingMode == 'api') ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.paper,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: const Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            size: 14,
                            color: AppColors.muted,
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Uses the Gemini key from API Keys.',
                              style: TextStyle(
                                fontFamily: 'Inter',
                                fontSize: 12,
                                color: AppColors.muted,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          const SettingsSectionLabel('Index books'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.stage,
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.all(16),
              child: SegmentedToggle<String>(
                options: const [
                  ('onAdd', 'On add'),
                  ('lazy', 'On first use'),
                  ('background', 'Background'),
                ],
                selected: indexingTrigger,
                onChanged: onIndexingTriggerChanged,
              ),
            ),
          ),

          const SettingsSectionLabel('How it works'),
          SettingsGroup(
            children: [
              _InfoRow(
                icon: Icons.upload_file_outlined,
                title: 'Books are indexed',
                subtitle: 'Text is split into chunks and embedded',
              ),
              _InfoRow(
                icon: Icons.search_outlined,
                title: 'Semantic search',
                subtitle: 'Relevant passages are found per question',
              ),
              _InfoRow(
                icon: Icons.chat_outlined,
                title: 'Context-aware answers',
                subtitle: 'AI responds using your book\'s content',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.icon,
    required this.title,
    required this.subtitle,
  });
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(
        children: [
          SettingsIconCircle(
            label: '',
            icon: icon,
            bgColor: AppColors.primary.withValues(alpha: 0.08),
            color: AppColors.primary,
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 15,
                  color: AppColors.ink,
                ),
              ),
              Text(
                subtitle,
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 12,
                  color: AppColors.muted,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
