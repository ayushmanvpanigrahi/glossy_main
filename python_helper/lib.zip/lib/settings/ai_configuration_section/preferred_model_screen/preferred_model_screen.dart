import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_models.dart';
import '../../common_widgets.dart';
import '../../model_widgets.dart';

class PreferredModelScreen extends StatelessWidget {
  const PreferredModelScreen({
    super.key,
    required this.isModelsLoading,
    required this.modelsFetchError,
    required this.onRefresh,
    required this.searchController,
    required this.onSearchChanged,
    required this.freeOnly,
    required this.onFreeOnlyChanged,
    required this.selectedProviders,
    required this.onProvidersChanged,
    required this.selectedTypes,
    required this.onTypesChanged,
    required this.allModels,
    required this.filteredModels,
    required this.fetchWarnings,
    required this.selectedModelId,
    required this.onSelectModel,
    required this.isPinging,
    required this.pingResult,
    required this.onPing,
  });

  final bool isModelsLoading;
  final String? modelsFetchError;
  final VoidCallback onRefresh;
  final TextEditingController searchController;
  final ValueChanged<String> onSearchChanged;
  final bool freeOnly;
  final ValueChanged<bool> onFreeOnlyChanged;
  final Set<ModelProvider> selectedProviders;
  final ValueChanged<Set<ModelProvider>> onProvidersChanged;
  final Set<ModelType> selectedTypes;
  final ValueChanged<Set<ModelType>> onTypesChanged;
  final List<OpenRouterModel> allModels;
  final List<OpenRouterModel> filteredModels;
  final List<String> fetchWarnings;
  final String? selectedModelId;
  final ValueChanged<String> onSelectModel;
  final bool isPinging;
  final ModelPingResult? pingResult;
  final VoidCallback onPing;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Preferred model',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
        actions: [
          isModelsLoading
              ? const Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.primary,
                    ),
                  ),
                )
              : IconButton(
                  icon: const Icon(
                    Icons.refresh_rounded,
                    color: AppColors.muted,
                  ),
                  onPressed: onRefresh,
                ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          if (modelsFetchError != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: InfoBanner(
                message: modelsFetchError!,
                color: AppColors.danger,
                icon: Icons.error_outline,
              ),
            )
          else ...[
            // Search
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.stage,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextField(
                  controller: searchController,
                  onChanged: onSearchChanged,
                  style: const TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 14,
                    color: AppColors.ink,
                  ),
                  decoration: const InputDecoration(
                    hintText: 'Search models...',
                    hintStyle: TextStyle(color: AppColors.muted, fontSize: 14),
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      size: 18,
                      color: AppColors.muted,
                    ),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                  ),
                ),
              ),
            ),
            // Count + free toggle
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 0, 14, 0),
              child: Row(
                children: [
                  Text(
                    '${filteredModels.length} models',
                    style: const TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 12,
                      color: AppColors.muted,
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'Free only',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 13,
                      color: AppColors.ink,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Switch(
                    value: freeOnly,
                    onChanged: onFreeOnlyChanged,
                    activeThumbColor: AppColors.primary,
                    activeTrackColor: AppColors.primary.withValues(alpha: 0.35),
                    inactiveThumbColor: AppColors.paper,
                    inactiveTrackColor: AppColors.muted.withValues(alpha: 0.3),
                    trackOutlineColor: WidgetStateProperty.all(
                      Colors.transparent,
                    ),
                  ),
                ],
              ),
            ),
            // Advanced Filters
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              child: Row(
                children: [
                  ...ModelProvider.values.map(
                    (p) => Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: FilterChip(
                        label: Text(p.name.toUpperCase()),
                        selected: selectedProviders.contains(p),
                        onSelected: (selected) {
                          final next = Set<ModelProvider>.from(
                            selectedProviders,
                          );
                          if (selected) {
                            next.add(p);
                          } else {
                            next.remove(p);
                          }
                          onProvidersChanged(next);
                        },
                        labelStyle: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: selectedProviders.contains(p)
                              ? Colors.white
                              : AppColors.ink,
                        ),
                        selectedColor: AppColors.primary,
                        checkmarkColor: Colors.white,
                        backgroundColor: AppColors.stage,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                    child: VerticalDivider(width: 1, indent: 8, endIndent: 8),
                  ),
                  ...ModelType.values.map(
                    (t) => Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: FilterChip(
                        label: Text(t.name.toUpperCase()),
                        selected: selectedTypes.contains(t),
                        onSelected: (selected) {
                          final next = Set<ModelType>.from(selectedTypes);
                          if (selected) {
                            next.add(t);
                          } else {
                            next.remove(t);
                          }
                          onTypesChanged(next);
                        },
                        labelStyle: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: selectedTypes.contains(t)
                              ? Colors.white
                              : AppColors.ink,
                        ),
                        selectedColor: AppColors.ink,
                        checkmarkColor: Colors.white,
                        backgroundColor: AppColors.stage,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Warnings
            for (final w in fetchWarnings)
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                child: InfoBanner(
                  message: w,
                  color: AppColors.warning,
                  icon: Icons.warning_amber_rounded,
                ),
              ),
            // Model list
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: ModelList(
                models: filteredModels,
                selectedModelId: selectedModelId,
                onSelect: onSelectModel,
              ),
            ),
            // Ping row
            if (selectedModelId != null) ...[
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: _PingRow(
                  modelId: selectedModelId!,
                  isPinging: isPinging,
                  pingResult: pingResult,
                  onPing: onPing,
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}

class _PingRow extends StatelessWidget {
  const _PingRow({
    required this.modelId,
    required this.isPinging,
    required this.pingResult,
    required this.onPing,
  });

  final String modelId;
  final bool isPinging;
  final ModelPingResult? pingResult;
  final VoidCallback onPing;

  (Color, String) get _state {
    if (isPinging) return (AppColors.warning, 'Testing model...');
    return switch (pingResult) {
      null => (AppColors.muted, 'Run model test'),
      ModelPingResult.success => (AppColors.success, 'Model is responding'),
      ModelPingResult.emptyResponse => (AppColors.warning, 'Empty response'),
      ModelPingResult.failed => (AppColors.danger, 'Model failed'),
      ModelPingResult.unauthorized => (AppColors.danger, 'Unauthorized'),
      ModelPingResult.networkError => (AppColors.warning, 'No connection'),
      ModelPingResult.noKey => (AppColors.muted, 'No API key set'),
    };
  }

  @override
  Widget build(BuildContext context) {
    final (color, label) = _state;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.20), width: 0.5),
      ),
      child: Row(
        children: [
          isPinging
              ? SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: color,
                  ),
                )
              : Icon(
                  pingResult == ModelPingResult.success
                      ? Icons.check_circle_outline_rounded
                      : Icons.play_circle_outline_rounded,
                  size: 18,
                  color: color,
                ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: color,
                  ),
                ),
                if (pingResult == ModelPingResult.success)
                  Text(
                    modelId,
                    style: const TextStyle(
                      fontFamily: 'JetBrainsMono',
                      fontSize: 10,
                      color: AppColors.muted,
                    ),
                  ),
              ],
            ),
          ),
          TextButton(
            onPressed: isPinging ? null : onPing,
            child: Text(
              pingResult == null ? 'Test' : 'Retest',
              style: const TextStyle(
                fontFamily: 'Inter',
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppColors.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
