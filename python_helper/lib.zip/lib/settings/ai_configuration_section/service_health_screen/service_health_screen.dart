import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_models.dart';
import '../../status_widgets.dart';

class ServiceHealthScreen extends StatelessWidget {
  const ServiceHealthScreen({
    super.key,
    required this.orStatus,
    required this.groqStatus,
    required this.geminiStatus,
    required this.aiStatus,
    required this.pingResult,
    required this.selectedModelId,
  });

  final KeyStatus orStatus;
  final KeyStatus groqStatus;
  final KeyStatus geminiStatus;
  final String aiStatus;
  final ModelPingResult? pingResult;
  final String? selectedModelId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Service health',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          HealthDashboard(
            orStatus: orStatus,
            groqStatus: groqStatus,
            geminiStatus: geminiStatus,
            aiStatus: aiStatus,
            pingResult: pingResult,
            selectedModelId: selectedModelId,
          ),
        ],
      ),
    );
  }
}
