import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_models.dart';
import '../../settings_rows.dart';

class ApiKeysScreen extends StatelessWidget {
  const ApiKeysScreen({
    super.key,
    required this.orKeyCtrl,
    required this.obscureOr,
    required this.onToggleObscureOr,
    required this.orStatus,
    required this.onValidateOr,
    required this.groqKeyCtrl,
    required this.obscureGroq,
    required this.onToggleObscureGroq,
    required this.groqStatus,
    required this.onValidateGroq,
    required this.geminiKeyCtrl,
    required this.obscureGemini,
    required this.onToggleObscureGemini,
    required this.geminiStatus,
    required this.onValidateGemini,
    required this.onSave,
    required this.isSaving,
  });

  final TextEditingController orKeyCtrl;
  final bool obscureOr;
  final VoidCallback onToggleObscureOr;
  final KeyStatus orStatus;
  final VoidCallback onValidateOr;

  final TextEditingController groqKeyCtrl;
  final bool obscureGroq;
  final VoidCallback onToggleObscureGroq;
  final KeyStatus groqStatus;
  final VoidCallback onValidateGroq;

  final TextEditingController geminiKeyCtrl;
  final bool obscureGemini;
  final VoidCallback onToggleObscureGemini;
  final KeyStatus geminiStatus;
  final VoidCallback onValidateGemini;

  final VoidCallback onSave;
  final bool isSaving;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'API keys',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
        actions: [
          TextButton(
            onPressed: isSaving ? null : onSave,
            child: isSaving
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.primary,
                    ),
                  )
                : const Text(
                    'Save',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: AppColors.primary,
                    ),
                  ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SettingsSectionLabel('Provider keys'),
          SettingsGroup(
            children: [
              _KeyRow(
                controller: orKeyCtrl,
                obscure: obscureOr,
                onToggleObscure: onToggleObscureOr,
                label: 'OpenRouter',
                hint: 'sk-or-v1-...',
                badgeLabel: 'OR',
                badgeColor: AppColors.primary,
                status: orStatus,
                onValidate: onValidateOr,
              ),
              _KeyRow(
                controller: groqKeyCtrl,
                obscure: obscureGroq,
                onToggleObscure: onToggleObscureGroq,
                label: 'Groq',
                hint: 'gsk_...',
                badgeLabel: 'GQ',
                badgeColor: const Color(0xFFF55036),
                status: groqStatus,
                onValidate: onValidateGroq,
              ),
              _KeyRow(
                controller: geminiKeyCtrl,
                obscure: obscureGemini,
                onToggleObscure: onToggleObscureGemini,
                label: 'Gemini',
                hint: 'AIza...',
                badgeLabel: 'GM',
                badgeColor: const Color(0xFF4285F4),
                status: geminiStatus,
                onValidate: onValidateGemini,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22),
            child: Text(
              'Keys are stored securely in your device\'s encrypted storage and never sent to Glossy servers.',
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 12,
                color: AppColors.muted.withValues(alpha: 0.8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Key input row ─────────────────────────────────────────────────────────────

class _KeyRow extends StatelessWidget {
  const _KeyRow({
    required this.controller,
    required this.obscure,
    required this.onToggleObscure,
    required this.label,
    required this.hint,
    required this.badgeLabel,
    required this.badgeColor,
    required this.status,
    required this.onValidate,
  });

  final TextEditingController controller;
  final bool obscure;
  final VoidCallback onToggleObscure;
  final String label;
  final String hint;
  final String badgeLabel;
  final Color badgeColor;
  final KeyStatus status;
  final VoidCallback onValidate;

  Color get _statusColor => switch (status) {
    KeyStatus.idle => AppColors.muted,
    KeyStatus.checking => AppColors.warning,
    KeyStatus.valid => AppColors.success,
    KeyStatus.invalid => AppColors.danger,
    KeyStatus.networkError => AppColors.warning,
  };

  String get _statusLabel => switch (status) {
    KeyStatus.idle => 'Not set',
    KeyStatus.checking => 'Checking...',
    KeyStatus.valid => 'Active',
    KeyStatus.invalid => 'Invalid',
    KeyStatus.networkError => 'Unreachable',
  };

  @override
  Widget build(BuildContext context) {
    final isChecking = status == KeyStatus.checking;
    final isValid = status == KeyStatus.valid;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: badgeColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  badgeLabel,
                  style: TextStyle(
                    fontFamily: 'JetBrainsMono',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: badgeColor,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                label,
                style: const TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.ink,
                ),
              ),
              const Spacer(),
              // Status pill
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _statusColor.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _statusColor.withValues(alpha: 0.30),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 5,
                      height: 5,
                      decoration: BoxDecoration(
                        color: _statusColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      _statusLabel,
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: _statusColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Input row
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  obscureText: obscure,
                  style: const TextStyle(
                    fontFamily: 'JetBrainsMono',
                    fontSize: 13,
                    color: AppColors.ink,
                  ),
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: const TextStyle(
                      fontFamily: 'JetBrainsMono',
                      fontSize: 12,
                      color: AppColors.muted,
                    ),
                    filled: true,
                    fillColor: AppColors.paper,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 11,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: AppColors.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                        color: isValid
                            ? AppColors.success.withValues(alpha: 0.5)
                            : AppColors.border,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: badgeColor, width: 1.5),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscure ? Icons.visibility_off : Icons.visibility,
                        size: 16,
                        color: AppColors.muted,
                      ),
                      onPressed: onToggleObscure,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 40,
                child: OutlinedButton(
                  onPressed: isChecking ? null : onValidate,
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    side: BorderSide(
                      color: isChecking
                          ? AppColors.border
                          : badgeColor.withValues(alpha: 0.5),
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: isChecking
                      ? SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: badgeColor,
                          ),
                        )
                      : Text(
                          'Test',
                          style: TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: badgeColor,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
