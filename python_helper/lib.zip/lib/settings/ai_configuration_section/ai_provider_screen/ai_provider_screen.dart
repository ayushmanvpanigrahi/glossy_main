import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_rows.dart';

class AiProviderScreen extends StatelessWidget {
  const AiProviderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'AI provider',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SettingsSectionLabel('Select provider'),
          SettingsGroup(
            children: [
              SettingsNavRow(
                iconWidget: SettingsIconCircle(
                  label: 'OR',
                  bgColor: AppColors.primary.withValues(alpha: 0.12),
                  color: AppColors.primary,
                ),
                title: 'OpenRouter',
                subtitle: 'Access 100+ models via one API',
                trailingWidget: const Icon(
                  Icons.check_circle_rounded,
                  size: 20,
                  color: AppColors.primary,
                ),
                showChevron: false,
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: SettingsIconCircle(
                  label: 'GQ',
                  bgColor: const Color(0xFFF55036).withValues(alpha: 0.12),
                  color: const Color(0xFFF55036),
                ),
                title: 'Groq',
                subtitle: 'Ultra-fast inference',
                showChevron: false,
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}
