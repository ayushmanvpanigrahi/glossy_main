import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_rows.dart';

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({super.key});
  @override
  State<LanguageScreen> createState() => _LanguageScreenState();
}

class _LanguageScreenState extends State<LanguageScreen> {
  String _selected = 'English';
  static const _languages = [
    'English',
    'हिन्दी',
    'Español',
    'Français',
    'Deutsch',
    '中文',
    '日本語',
    'العربية',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Language',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SettingsSectionLabel('App language'),
          SettingsGroup(
            children: _languages
                .map(
                  (lang) => SettingsNavRow(
                    iconWidget: const SettingsIconCircle(
                      label: '⇌',
                      icon: Icons.language_outlined,
                    ),
                    title: lang,
                    showChevron: false,
                    trailingWidget: _selected == lang
                        ? const Icon(
                            Icons.check_rounded,
                            size: 18,
                            color: AppColors.primary,
                          )
                        : null,
                    onTap: () => setState(() => _selected = lang),
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }
}
