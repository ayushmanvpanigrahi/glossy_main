import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_rows.dart';

class PrivacyAndDataScreen extends StatelessWidget {
  const PrivacyAndDataScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Privacy and data',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SettingsSectionLabel('Your data'),
          SettingsGroup(
            children: [
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '⬇',
                  icon: Icons.download_outlined,
                ),
                title: 'Export my data',
                subtitle: 'Download all your books and notes',
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: SettingsIconCircle(
                  label: '🗑',
                  icon: Icons.delete_outline,
                  color: AppColors.danger,
                  bgColor: AppColors.danger.withValues(alpha: 0.10),
                ),
                title: 'Delete account',
                subtitle: 'Permanently remove all data',
                trailingText: '',
                showChevron: true,
                onTap: () {},
              ),
            ],
          ),
          const SettingsSectionLabel('Legal'),
          SettingsGroup(
            children: [
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '📄',
                  icon: Icons.description_outlined,
                ),
                title: 'Privacy policy',
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '📋',
                  icon: Icons.article_outlined,
                ),
                title: 'Terms of service',
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}
