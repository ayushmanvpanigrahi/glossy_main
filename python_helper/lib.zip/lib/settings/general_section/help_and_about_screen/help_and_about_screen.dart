import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_rows.dart';

class HelpAndAboutScreen extends StatelessWidget {
  const HelpAndAboutScreen({super.key, required this.appVersion});
  final String appVersion;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            size: 18,
            color: AppColors.ink,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Help and about',
          style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontStyle: FontStyle.italic,
            color: AppColors.ink,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Glossy',
              style: TextStyle(
                fontFamily: 'PlayfairDisplay',
                fontSize: 32,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                color: AppColors.ink,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text(
              appVersion,
              style: const TextStyle(
                fontFamily: 'Inter',
                fontSize: 13,
                color: AppColors.muted,
              ),
            ),
          ),
          const SizedBox(height: 28),
          const SettingsSectionLabel('Support'),
          SettingsGroup(
            children: [
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '?',
                  icon: Icons.help_outline_rounded,
                ),
                title: 'FAQ',
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '✉',
                  icon: Icons.mail_outline_rounded,
                ),
                title: 'Contact support',
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '⭐',
                  icon: Icons.star_outline_rounded,
                ),
                title: 'Rate Glossy',
                onTap: () {},
              ),
            ],
          ),
          const SettingsSectionLabel('About'),
          SettingsGroup(
            children: [
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: 'v',
                  icon: Icons.update_outlined,
                ),
                title: 'Version',
                trailingText: appVersion,
                showChevron: false,
                onTap: null,
              ),
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '📄',
                  icon: Icons.description_outlined,
                ),
                title: 'Open source licenses',
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}
