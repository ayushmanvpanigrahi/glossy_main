import 'package:flutter/material.dart';
import '../../../app_colors.dart';
import '../../settings_rows.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.secondary,
      appBar: _settingsAppBar(context, 'Profile'),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 40),
        children: [
          const SizedBox(height: 24),
          Center(
            child: Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: AppColors.primary,
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: const Text(
                'AM',
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 26,
                  fontWeight: FontWeight.w600,
                  color: AppColors.paper,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'Aarav Mehta',
              style: TextStyle(
                fontFamily: 'PlayfairDisplay',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.ink,
              ),
            ),
          ),
          const SizedBox(height: 4),
          const Center(
            child: Text(
              'aarav@glossy.app',
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 13,
                color: AppColors.muted,
              ),
            ),
          ),
          const SizedBox(height: 28),
          const SettingsSectionLabel('Account details'),
          SettingsGroup(
            children: [
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '✎',
                  icon: Icons.person_outline,
                ),
                title: 'Edit name',
                trailingText: 'Aarav Mehta',
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '@',
                  icon: Icons.alternate_email,
                ),
                title: 'Email',
                trailingText: 'aarav@glossy.app',
                onTap: () {},
              ),
              SettingsNavRow(
                iconWidget: const SettingsIconCircle(
                  label: '🔑',
                  icon: Icons.lock_outline,
                ),
                title: 'Change password',
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}

AppBar _settingsAppBar(BuildContext context, String title) => AppBar(
  backgroundColor: AppColors.secondary,
  elevation: 0,
  scrolledUnderElevation: 0,
  leading: IconButton(
    icon: const Icon(Icons.arrow_back_ios, size: 18, color: AppColors.ink),
    onPressed: () => Navigator.pop(context),
  ),
  title: Text(
    title,
    style: const TextStyle(
      fontFamily: 'PlayfairDisplay',
      fontSize: 20,
      fontWeight: FontWeight.bold,
      fontStyle: FontStyle.italic,
      color: AppColors.ink,
    ),
  ),
);
