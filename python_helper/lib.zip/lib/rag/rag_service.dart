// import 'embedding_service.dart';
// import 'rag_models.dart';
// import 'text_chunker.dart';
// import 'vector_store.dart';
//
// class RagService {
//   RagService({required this.embeddingService, TextChunker? chunker})
//       : _chunker = chunker ?? const TextChunker();
//
//   final EmbeddingService embeddingService;
//   final TextChunker _chunker;
//
//   /// Call wherever the app currently extracts a book's plain text —
//   /// on add / lazily / from background, depending on the user's setting.
//   Future<void> indexBook(String bookId, String fullText) async {
//     final store = await VectorStore.instance();
//     final pieces = _chunker.chunk(fullText);
//     if (pieces.isEmpty) return;
//
//     final chunks = <TextChunk>[];
//     for (var i = 0; i < pieces.length; i++) {
//       final embedding = await embeddingService.embed(pieces[i]);
//       chunks.add(TextChunk(
//         id: '$bookId#$i',
//         bookId: bookId,
//         chunkIndex: i,
//         text: pieces[i],
//         embedding: embedding,
//       ));
//     }
//     await store.upsertChunks(chunks);
//   }
//
//   Future<bool> isIndexed(String bookId) async =>
//       (await VectorStore.instance()).isBookIndexed(bookId);
//
//   Future<void> removeBook(String bookId) async =>
//       (await VectorStore.instance()).deleteBook(bookId);
//
//   /// Retrieves relevant chunks for a question, ready to prepend to a
//   /// chat-completion prompt as context.
//   Future<String> retrieveContext(
//       String question, {
//         String? bookId,
//         int topK = 5,
//       }) async {
//     final store = await VectorStore.instance();
//     final queryEmbedding = await embeddingService.embed(question);
//     final results = await store.search(queryEmbedding, bookId: bookId, topK: topK);
//     if (results.isEmpty) return '';
//     return results
//         .map((r) => '[chunk ${r.chunk.chunkIndex}] ${r.chunk.text}')
//         .join('\n\n');
//   }
// }

import 'embedding_service.dart';
import 'rag_models.dart';
import 'text_chunker.dart';
import 'vector_store.dart';

class RagService {
  RagService({required this.embeddingService, TextChunker? chunker})
    : _chunker = chunker ?? const TextChunker();

  final EmbeddingService embeddingService;
  final TextChunker _chunker;

  /// Call wherever the app currently extracts a book's plain text —
  /// on add / lazily / from background, depending on the user's setting.
  ///
  /// CHANGES:
  /// - Added [onProgress] so the UI can show a live "42/238 chunks" style
  ///   indicator instead of a silent black box (issue #4).
  /// - Now clears any existing chunks for [bookId] first, so re-indexing
  ///   (e.g. via a manual "Index now" button) is idempotent instead of
  ///   accumulating duplicate/stale chunks from a previous run.
  Future<void> indexBook(
    String bookId,
    String fullText, {
    void Function(int done, int total)? onProgress,
  }) async {
    final store = await VectorStore.instance();
    await store.deleteBook(bookId);

    final pieces = _chunker.chunk(fullText);
    if (pieces.isEmpty) {
      onProgress?.call(0, 0);
      return;
    }

    onProgress?.call(0, pieces.length);

    final chunks = <TextChunk>[];
    const batchSize = 100; // Gemini limit

    for (var i = 0; i < pieces.length; i += batchSize) {
      final end = (i + batchSize < pieces.length)
          ? i + batchSize
          : pieces.length;
      final subList = pieces.sublist(i, end);

      final embeddings = await embeddingService.embedBatch(subList);

      for (var j = 0; j < subList.length; j++) {
        chunks.add(
          TextChunk(
            id: '$bookId#${i + j}',
            bookId: bookId,
            chunkIndex: i + j,
            text: subList[j],
            embedding: embeddings[j],
          ),
        );
      }
      onProgress?.call(chunks.length, pieces.length);
    }

    await store.upsertChunks(chunks);
  }

  Future<bool> isIndexed(String bookId) async =>
      (await VectorStore.instance()).isBookIndexed(bookId);

  Future<void> removeBook(String bookId) async =>
      (await VectorStore.instance()).deleteBook(bookId);

  /// Retrieves relevant chunks for a question, ready to prepend to a
  /// chat-completion prompt as context.
  Future<String> retrieveContext(
    String question, {
    String? bookId,
    int topK = 5,
  }) async {
    final store = await VectorStore.instance();
    final queryEmbedding = await embeddingService.embed(question);
    final results = await store.search(
      queryEmbedding,
      bookId: bookId,
      topK: topK,
    );
    if (results.isEmpty) return '';
    return results
        .map((r) => '[chunk ${r.chunk.chunkIndex}] ${r.chunk.text}')
        .join('\n\n');
  }
}
