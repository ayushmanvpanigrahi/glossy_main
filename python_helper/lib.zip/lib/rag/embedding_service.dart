import 'dart:convert';
import 'package:http/http.dart' as http;

abstract class EmbeddingService {
  Future<List<double>> embed(String text);
  Future<List<List<double>>> embedBatch(List<String> texts);
}

/// Google Gemini embedding API — generous free tier, separate key from
/// the OpenRouter key already used for chat completions.
class GeminiEmbeddingService implements EmbeddingService {
  GeminiEmbeddingService(this.apiKey);
  final String apiKey;

  // 'text-embedding-004' returns 404 on some regions/accounts with v1beta.
  // 'embedding-001' is the stable, universally available Gemini embedding
  // model and works on both v1 and v1beta.
  static const _model = 'gemini-embedding-002';
  static const _baseEndpoint =
      'https://generativelanguage.googleapis.com/v1beta/models/$_model';

  @override
  Future<List<double>> embed(String text) async {
    final uri = Uri.parse('$_baseEndpoint:embedContent?key=$apiKey');
    final response = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'model': 'models/$_model',
            'content': {
              'parts': [
                {'text': text},
              ],
            },
          }),
        )
        .timeout(const Duration(seconds: 15));

    if (response.statusCode != 200) {
      throw EmbeddingException(
        'Embedding failed (${response.statusCode}): ${response.body}',
      );
    }
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    final values = (json['embedding']['values'] as List).cast<num>();
    return values.map((n) => n.toDouble()).toList();
  }

  @override
  Future<List<List<double>>> embedBatch(List<String> texts) async {
    if (texts.isEmpty) return [];

    // Gemini batch limit is 100 per request
    const batchSize = 100;
    final allResults = <List<double>>[];

    for (var i = 0; i < texts.length; i += batchSize) {
      final end = (i + batchSize < texts.length) ? i + batchSize : texts.length;
      final subList = texts.sublist(i, end);

      final uri = Uri.parse('$_baseEndpoint:batchEmbedContents?key=$apiKey');
      final response = await http
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'requests': subList
                  .map(
                    (t) => {
                      'model': 'models/$_model',
                      'content': {
                        'parts': [
                          {'text': t},
                        ],
                      },
                    },
                  )
                  .toList(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode != 200) {
        throw EmbeddingException(
          'Batch embedding failed (${response.statusCode}): ${response.body}',
        );
      }

      final json = jsonDecode(response.body) as Map<String, dynamic>;
      final embeddings = json['embeddings'] as List;
      for (final e in embeddings) {
        final values = (e['values'] as List).cast<num>();
        allResults.add(values.map((n) => n.toDouble()).toList());
      }
    }

    return allResults;
  }
}

/// Placeholder for on-device embeddings (tflite_flutter + a bundled
/// MiniLM/sentence-transformer model). Same interface, so RagService
/// doesn't need to change once this is wired up — just needs a model
/// asset (~25-90MB depending on model) bundled or downloaded on first use.
class LocalEmbeddingService implements EmbeddingService {
  const LocalEmbeddingService();

  @override
  Future<List<double>> embed(String text) {
    throw UnimplementedError(
      'Local embeddings model not bundled yet — see TODO in '
      'embedding_service.dart before enabling this mode.',
    );
  }

  @override
  Future<List<List<double>>> embedBatch(List<String> texts) {
    throw UnimplementedError('Local batch embeddings not implemented.');
  }
}

class EmbeddingException implements Exception {
  EmbeddingException(this.message);
  final String message;
  @override
  String toString() => message;
}
